﻿using Microsoft.Data.SqlClient;
using System.Data;
using System.Drawing;

namespace hihi
{
    public partial class fLogin : Form
    {
        string sCon = "Data Source=LAPTOP-TIPVOAM1;Initial Catalog=PTRO;Integrated Security=True;Trust Server Certificate=True";
        public fLogin()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void fLogin_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (MessageBox.Show("Bạn chắn chắn muốn thoát chương trình?", "Thông báo", MessageBoxButtons.OKCancel) != System.Windows.Forms.DialogResult.OK)
            {
                e.Cancel = true;

            }
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            string username = txtBUsername.Text;
            string password = txtBPassword.Text;
            if (login(username, password))
            {

                fTableManager f = new fTableManager();
                this.Hide();
                f.ShowDialog();
                this.Show();
            }
            else
            {
                MessageBox.Show("Sai tên tài khoản hoặc mật khẩu!", "Thông báo");
            }    
        }

        bool login(string username, string password)
        {
           
            SqlConnection con = new SqlConnection(sCon);
            {
                try
                {
                    con.Open();

                    using (SqlCommand cmd = new SqlCommand("USP_Login", con))
                    {
                        cmd.CommandType = CommandType.StoredProcedure;

                        cmd.Parameters.AddWithValue("@Username", username);
                        cmd.Parameters.AddWithValue("@Password", password);

                        cmd.Parameters.Add(new SqlParameter
                        {
                            ParameterName = "@ReturnValue",
                            SqlDbType = SqlDbType.Int,
                            Direction = ParameterDirection.ReturnValue
                        });

                        cmd.ExecuteNonQuery();

                        int returnValue = Convert.ToInt32(cmd.Parameters["@ReturnValue"].Value);

                        if (returnValue == 1)
                        {
                            return true; 
                        }
                        else
                        {
                            return false; 
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Lỗi khi kết nối đến cơ sở dữ liệu: " + ex.Message, "Thông báo");
                    return false;
                }
            }
        }
    }
}
