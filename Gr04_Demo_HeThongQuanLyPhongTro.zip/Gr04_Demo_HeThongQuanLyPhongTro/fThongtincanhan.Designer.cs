﻿namespace hihi
{
    partial class fThongtincanhan
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(fThongtincanhan));
            panel3 = new Panel();
            txtbInfAc_id = new TextBox();
            lblAcinf_CCCD = new Label();
            btnAc_Exit = new Button();
            panel2 = new Panel();
            txtbAcInf_phone = new TextBox();
            lblAcinf_SDT = new Label();
            panel1 = new Panel();
            txtbInfAc_name = new TextBox();
            lblAcinf_name = new Label();
            pictureBox2 = new PictureBox();
            panel4 = new Panel();
            panel5 = new Panel();
            txtbInfAc_add = new TextBox();
            lblAcinf_add = new Label();
            btnAc_luu = new Button();
            panel3.SuspendLayout();
            panel2.SuspendLayout();
            panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).BeginInit();
            panel4.SuspendLayout();
            panel5.SuspendLayout();
            SuspendLayout();
            // 
            // panel3
            // 
            panel3.Controls.Add(txtbInfAc_id);
            panel3.Controls.Add(lblAcinf_CCCD);
            panel3.Location = new Point(33, 133);
            panel3.Name = "panel3";
            panel3.Size = new Size(515, 49);
            panel3.TabIndex = 11;
            // 
            // txtbInfAc_id
            // 
            txtbInfAc_id.Location = new Point(117, 8);
            txtbInfAc_id.Name = "txtbInfAc_id";
            txtbInfAc_id.Size = new Size(344, 27);
            txtbInfAc_id.TabIndex = 6;
            // 
            // lblAcinf_CCCD
            // 
            lblAcinf_CCCD.AutoSize = true;
            lblAcinf_CCCD.Location = new Point(11, 15);
            lblAcinf_CCCD.Name = "lblAcinf_CCCD";
            lblAcinf_CCCD.Size = new Size(71, 20);
            lblAcinf_CCCD.TabIndex = 3;
            lblAcinf_CCCD.Text = "Số CCCD:";
            // 
            // btnAc_Exit
            // 
            btnAc_Exit.BackColor = Color.Red;
            btnAc_Exit.ForeColor = SystemColors.ButtonFace;
            btnAc_Exit.Location = new Point(453, 396);
            btnAc_Exit.Name = "btnAc_Exit";
            btnAc_Exit.Size = new Size(101, 46);
            btnAc_Exit.TabIndex = 16;
            btnAc_Exit.Text = "Thoát";
            btnAc_Exit.UseVisualStyleBackColor = false;
            // 
            // panel2
            // 
            panel2.Controls.Add(txtbAcInf_phone);
            panel2.Controls.Add(lblAcinf_SDT);
            panel2.Location = new Point(33, 78);
            panel2.Name = "panel2";
            panel2.Size = new Size(515, 49);
            panel2.TabIndex = 10;
            // 
            // txtbAcInf_phone
            // 
            txtbAcInf_phone.Location = new Point(117, 12);
            txtbAcInf_phone.Name = "txtbAcInf_phone";
            txtbAcInf_phone.Size = new Size(344, 27);
            txtbAcInf_phone.TabIndex = 5;
            // 
            // lblAcinf_SDT
            // 
            lblAcinf_SDT.AutoSize = true;
            lblAcinf_SDT.Location = new Point(11, 15);
            lblAcinf_SDT.Name = "lblAcinf_SDT";
            lblAcinf_SDT.Size = new Size(100, 20);
            lblAcinf_SDT.TabIndex = 3;
            lblAcinf_SDT.Text = "Số điện thoại:";
            // 
            // panel1
            // 
            panel1.Controls.Add(txtbInfAc_name);
            panel1.Controls.Add(lblAcinf_name);
            panel1.Location = new Point(33, 23);
            panel1.Name = "panel1";
            panel1.Size = new Size(515, 49);
            panel1.TabIndex = 9;
            // 
            // txtbInfAc_name
            // 
            txtbInfAc_name.Location = new Point(117, 10);
            txtbInfAc_name.Name = "txtbInfAc_name";
            txtbInfAc_name.Size = new Size(344, 27);
            txtbInfAc_name.TabIndex = 4;
            // 
            // lblAcinf_name
            // 
            lblAcinf_name.AutoSize = true;
            lblAcinf_name.Location = new Point(11, 17);
            lblAcinf_name.Name = "lblAcinf_name";
            lblAcinf_name.Size = new Size(76, 20);
            lblAcinf_name.TabIndex = 3;
            lblAcinf_name.Text = "Họ và tên:";
            // 
            // pictureBox2
            // 
            pictureBox2.Image = Properties.Resources.account_avatar_face_man_people_profile_user_icon_123197;
            pictureBox2.Location = new Point(278, 3);
            pictureBox2.Name = "pictureBox2";
            pictureBox2.Size = new Size(122, 113);
            pictureBox2.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox2.TabIndex = 15;
            pictureBox2.TabStop = false;
            // 
            // panel4
            // 
            panel4.Controls.Add(panel5);
            panel4.Controls.Add(panel1);
            panel4.Controls.Add(panel3);
            panel4.Controls.Add(panel2);
            panel4.Location = new Point(60, 122);
            panel4.Name = "panel4";
            panel4.Size = new Size(566, 253);
            panel4.TabIndex = 17;
            // 
            // panel5
            // 
            panel5.Controls.Add(txtbInfAc_add);
            panel5.Controls.Add(lblAcinf_add);
            panel5.Location = new Point(33, 190);
            panel5.Name = "panel5";
            panel5.Size = new Size(515, 49);
            panel5.TabIndex = 12;
            // 
            // txtbInfAc_add
            // 
            txtbInfAc_add.Location = new Point(117, 8);
            txtbInfAc_add.Name = "txtbInfAc_add";
            txtbInfAc_add.Size = new Size(344, 27);
            txtbInfAc_add.TabIndex = 6;
            // 
            // lblAcinf_add
            // 
            lblAcinf_add.AutoSize = true;
            lblAcinf_add.Location = new Point(11, 15);
            lblAcinf_add.Name = "lblAcinf_add";
            lblAcinf_add.Size = new Size(58, 20);
            lblAcinf_add.TabIndex = 3;
            lblAcinf_add.Text = "Địa chỉ:";
            // 
            // btnAc_luu
            // 
            btnAc_luu.BackColor = Color.DeepSkyBlue;
            btnAc_luu.ForeColor = SystemColors.ButtonFace;
            btnAc_luu.Location = new Point(325, 396);
            btnAc_luu.Name = "btnAc_luu";
            btnAc_luu.Size = new Size(101, 46);
            btnAc_luu.TabIndex = 18;
            btnAc_luu.Text = "Lưu";
            btnAc_luu.UseVisualStyleBackColor = false;
            // 
            // fThongtincanhan
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(674, 498);
            Controls.Add(btnAc_Exit);
            Controls.Add(pictureBox2);
            Controls.Add(panel4);
            Controls.Add(btnAc_luu);
            Icon = (Icon)resources.GetObject("$this.Icon");
            Name = "fThongtincanhan";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Thông tin cá nhân";
            panel3.ResumeLayout(false);
            panel3.PerformLayout();
            panel2.ResumeLayout(false);
            panel2.PerformLayout();
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).EndInit();
            panel4.ResumeLayout(false);
            panel5.ResumeLayout(false);
            panel5.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private Panel panel3;
        private TextBox txtbInfAc_id;
        private Label lblAcinf_CCCD;
        private Button btnAc_Exit;
        private Panel panel2;
        private TextBox txtbAcInf_phone;
        private Label lblAcinf_SDT;
        private Panel panel1;
        private TextBox txtbInfAc_name;
        private Label lblAcinf_name;
        private PictureBox pictureBox2;
        private Panel panel4;
        private Panel panel5;
        private TextBox txtbInfAc_add;
        private Label lblAcinf_add;
        private Button btnAc_luu;
    }
}