﻿using System.Data;
using System.Drawing;
using Microsoft.Data.SqlClient;

namespace hihi
{
    public partial class fAdmincs : Form
    {
        string sCon = "Data Source=LAPTOP-TIPVOAM1;Initial Catalog=PTRO;Integrated Security=True;Trust Server Certificate=True";
        public fAdmincs()
        {
            InitializeComponent();

            LoadPhong_TroList();
            LoadPhong_TrocchthueList();
            LoadKhach_ThueList();
            LoadHop_DongList();
            LoadBSXList();
            LoadDVList();
            LoadTKKhach_thueList();
            LoadcomboBoxRoomHoaDon_idList();

            LoadcomboBoxServicesHoaDon_dv_idList();
            ConfigureListViewHoaDon();
            LoadHDon_ChiTietList();
            LoadcomboBoxHD_p_idList();
            LoadHDonList();
            LoadHDonChuaThanhToan();
        }

        private void textBox11_TextChanged(object sender, EventArgs e)
        {

        }

        private void datagridviewPhong_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        void LoadPhong_TroList()
        {
            SqlConnection con = new SqlConnection(sCon);
            try
            {
                con.Open();
                string query = "SELECT * FROM phong_tro";
                SqlCommand command = new SqlCommand(query, con);

                DataTable data = new DataTable();
                SqlDataAdapter adapter = new SqlDataAdapter(command);

                adapter.Fill(data);

                dtgvPhong_tro.DataSource = data;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Xảy ra lỗi: {ex.Message}", "Thông báo");
            }
            finally
            {
                con.Close();
            }
        }
        void LoadPhong_TrocchthueList()
        {
            SqlConnection con = new SqlConnection(sCon);
            try
            {
                con.Open();

                string query = "SELECT P_ID, P_giaphong, P_soluong FROM phong_tro WHERE P_TinhTrang = 0";
                SqlCommand command = new SqlCommand(query, con);

                DataTable data = new DataTable();
                SqlDataAdapter adapter = new SqlDataAdapter(command);

                adapter.Fill(data);

                dtgvPchuathue.DataSource = data;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Xảy ra lỗi: {ex.Message}", "Thông báo");
            }
            finally
            {
                con.Close();
            }
        }

        void LoadHDon_ChiTietList()
        {
            SqlConnection con = new SqlConnection(sCon);
            try
            {
                con.Open();

                string query = @"SELECT *
                         FROM HDon_Chi_Tiet";

                SqlCommand command = new SqlCommand(query, con);

                DataTable data = new DataTable();

                SqlDataAdapter adapter = new SqlDataAdapter(command);

                adapter.Fill(data);

                dataGridViewHoadonCT.DataSource = data;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Xảy ra lỗi: {ex.Message}", "Thông báo");
            }
            finally
            {
                con.Close();
            }
        }

        void LoadHDonList()
        {
            using (SqlConnection con = new SqlConnection(sCon))
            {
                try
                {
                    con.Open();

                    string query = @"SELECT * FROM hoa_don";

                    using (SqlCommand command = new SqlCommand(query, con))
                    {
                        SqlDataAdapter adapter = new SqlDataAdapter(command);
                        DataTable data = new DataTable();
                        adapter.Fill(data);
                        dtgvHoaDon.DataSource = data;
                    }
                }
                catch (Exception ex)
                {

                    MessageBox.Show($"Xảy ra lỗi: {ex.Message}", "Thông báo");
                }
            }
        }

        void LoadHDonChuaThanhToan()
        {
            using (SqlConnection con = new SqlConnection(sCon))
            {
                try
                {
                    con.Open();

                    string query = @"
                SELECT p_id, hdon_ngaythangnam
                FROM hoa_don 
                WHERE hdon_tinhtrang = 0";

                    using (SqlCommand command = new SqlCommand(query, con))
                    {
                        SqlDataAdapter adapter = new SqlDataAdapter(command);
                        DataTable data = new DataTable();
                        adapter.Fill(data);

                        dtgvHdonchThanhtoan.DataSource = data;
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Xảy ra lỗi: {ex.Message}", "Thông báo");
                }
            }
        }

        void LoadKhach_ThueList()
        {
            SqlConnection con = new SqlConnection(sCon);
            try
            {
                con.Open();
                string query = "SELECT KT_CCCD, KT_ten, KT_SDT, KT_gioitinh, KT_Hokhau FROM khach_thue";
                SqlCommand command = new SqlCommand(query, con);

                DataTable data = new DataTable();
                SqlDataAdapter adapter = new SqlDataAdapter(command);

                adapter.Fill(data);

                dtgvKhach_Thue.DataSource = data;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Xảy ra lỗi: {ex.Message}", "Thông báo");
            }
            finally
            {
                con.Close();
            }
        }

        void LoadHop_DongList()
        {
            SqlConnection con = new SqlConnection(sCon);
            try
            {
                con.Open();
                string query = "SELECT HDong_ID, HDong_tinhtrang, ct_cccd, kt_cccd, p_id, HDong_ngaybatdau, Hdong_ngayketthuc, Hdong_tiendatcoc FROM hop_dong";
                SqlCommand command = new SqlCommand(query, con);

                DataTable data = new DataTable();
                SqlDataAdapter adapter = new SqlDataAdapter(command);

                adapter.Fill(data);

                dtvgHopDong.DataSource = data;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Xảy ra lỗi: {ex.Message}", "Thông báo");
            }
            finally
            {
                con.Close();
            }
        }

        void LoadBSXList()
        {
            SqlConnection con = new SqlConnection(sCon);
            try
            {
                con.Open();
                string query = "SELECT * FROM Bien_So_Xe";
                SqlCommand command = new SqlCommand(query, con);

                DataTable data = new DataTable();
                SqlDataAdapter adapter = new SqlDataAdapter(command);

                adapter.Fill(data);

                dtvgBSX.DataSource = data;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Xảy ra lỗi: {ex.Message}", "Thông báo");
            }
            finally
            {
                con.Close();
            }
        }

        void LoadDVList()
        {
            SqlConnection con = new SqlConnection(sCon);
            try
            {
                con.Open();
                string query = "SELECT * FROM Dich_vu";
                SqlCommand command = new SqlCommand(query, con);

                DataTable data = new DataTable();
                SqlDataAdapter adapter = new SqlDataAdapter(command);

                adapter.Fill(data);

                dtgvDichVu.DataSource = data;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Xảy ra lỗi: {ex.Message}", "Thông báo");
            }
            finally
            {
                con.Close();
            }
        }

        void LoadTKKhach_thueList()
        {
            SqlConnection con = new SqlConnection(sCon);
            try
            {
                con.Open();
                string query = "SELECT TKKT_TenDN, TKKT_MK, kt_cccd FROM TK_Khach_Thue";
                SqlCommand command = new SqlCommand(query, con);

                DataTable data = new DataTable();
                SqlDataAdapter adapter = new SqlDataAdapter(command);

                adapter.Fill(data);

                dtgvTKKT.DataSource = data;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Xảy ra lỗi: {ex.Message}", "Thông báo");
            }
            finally
            {
                con.Close();
            }
        }
        private void fAdmincs_Load(object sender, EventArgs e)
        {

        }

        private void numericUpDown1_ValueChanged(object sender, EventArgs e)
        {

        }

        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void ResetFormPhongTro()
        {
            txtBP_ID.Text = string.Empty;
            txtBPprice.Text = string.Empty;

            numUDP_SL.Value = numUDP_SL.Minimum;
            numUDP_tinhtrang.Value = numUDP_tinhtrang.Minimum;
            txtBP_ID.Enabled = true;

        }

        private void btnThem_P_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(sCon);
            try
            {
                con.Open();
                string sP_ID = txtBP_ID.Text;
                string sP_gia = txtBPprice.Text;
                string sP_Soluong = numUDP_SL.Value.ToString();
                string sP_tinhtrang = numUDP_tinhtrang.Value.ToString();

                string query = "Insert into Phong_tro values (@P_ID, @P_soluong, @P_giaphong, @P_tinhtrang)";
                SqlCommand cmd = new SqlCommand(query, con);
                cmd.Parameters.AddWithValue("@P_ID", sP_ID);
                cmd.Parameters.AddWithValue("@P_soluong", sP_Soluong);
                cmd.Parameters.AddWithValue("@P_giaphong", sP_gia);
                cmd.Parameters.AddWithValue("@P_tinhtrang", sP_tinhtrang);
                try
                {
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Thêm dữ liệu thành công!", "Thông báo");
                    LoadPhong_TroList();
                    LoadPhong_TrocchthueList();
                    ResetFormPhongTro();
                }
                catch
                {
                    MessageBox.Show("Thêm dữ liệu thất bại!", "Thông báo");
                    ResetFormPhongTro();
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show("Xảy ra lỗi trong quá trình kết nối DB", "Thông báo");
            }
            finally
            {
                con.Close();
            }

        }

        private void dtgvPhong_tro_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                txtBP_ID.Text = dtgvPhong_tro.Rows[e.RowIndex].Cells["P_ID"].Value.ToString();

                numUDP_SL.Value = Convert.ToDecimal(dtgvPhong_tro.Rows[e.RowIndex].Cells["P_SoLuong"].Value);

                txtBPprice.Text = dtgvPhong_tro.Rows[e.RowIndex].Cells["P_GiaPhong"].Value.ToString();

                numUDP_tinhtrang.Value = Convert.ToDecimal(dtgvPhong_tro.Rows[e.RowIndex].Cells["P_TinhTrang"].Value);

                txtBP_ID.Enabled = false;
            }
        }

        private void btnCapNhat_P_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(sCon);
            try
            {
                con.Open();
                string sP_ID = txtBP_ID.Text;
                string sP_gia = txtBPprice.Text;
                string sP_Soluong = numUDP_SL.Value.ToString();
                string sP_tinhtrang = numUDP_tinhtrang.Value.ToString();

                string query = "Update Phong_tro set P_SoLuong=@P_soluong, P_GiaPhong=@P_giaphong, P_TinhTrang=@P_tinhtrang where P_ID=@P_ID";
                SqlCommand cmd = new SqlCommand(query, con);
                cmd.Parameters.AddWithValue("@P_ID", sP_ID);
                cmd.Parameters.AddWithValue("@P_soluong", sP_Soluong);
                cmd.Parameters.AddWithValue("@P_giaphong", sP_gia);
                cmd.Parameters.AddWithValue("@P_tinhtrang", sP_tinhtrang);
                try
                {
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Cập nhật thành công!", "Thông báo");
                    LoadPhong_TroList();
                    LoadPhong_TrocchthueList();
                    ResetFormPhongTro();
                }
                catch
                {
                    MessageBox.Show("Cập nhật thất bại!", "Thông báo");
                    ResetFormPhongTro();
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show("Xảy ra lỗi trong quá trình kết nối DB", "Thông báo");
            }
            finally
            {
                con.Close();
            }
        }

        private void btnXoa_P_Click(object sender, EventArgs e)
        {
            DialogResult ret = MessageBox.Show("Bạn có chắc chắn muốn xoá không?", "Thông báo", MessageBoxButtons.OKCancel);
            if (ret == DialogResult.OK)
            {
                SqlConnection con = new SqlConnection(sCon);
                try
                {
                    con.Open();
                    string sP_ID = txtBP_ID.Text;


                    string query = "delete phong_tro where P_ID= @P_ID";
                    SqlCommand cmd = new SqlCommand(query, con);
                    cmd.Parameters.AddWithValue("@P_ID", sP_ID);

                    try
                    {
                        cmd.ExecuteNonQuery();
                        MessageBox.Show("Xoá thành công!", "Thông báo");
                        LoadPhong_TroList();
                        LoadPhong_TrocchthueList();
                        ResetFormPhongTro();
                    }
                    catch
                    {
                        MessageBox.Show("Xoá thất bại!", "Thông báo");
                        ResetFormPhongTro();
                    }

                }
                catch (Exception ex)
                {
                    MessageBox.Show("Xảy ra lỗi trong quá trình kết nối DB", "Thông báo");
                }
                finally
                {
                    con.Close();
                }
            }

        }
        ///-----------------------------------------------------------
        private void ResetFormBSX()
        {
            txtBBSX_id.Text = string.Empty;
            txtBBSX_cccd_kt.Text = string.Empty;

            txtBBSX_id.Enabled = true;

        }

        private void dtvgBSX_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {

                txtBBSX_id.Text = dtvgBSX.Rows[e.RowIndex].Cells["BSX_ID"].Value.ToString();
                txtBBSX_cccd_kt.Text = dtvgBSX.Rows[e.RowIndex].Cells["kt_cccd"].Value.ToString();
                txtBBSX_id.Enabled = false;
            }
        }

        private void btnThem_BSX_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(sCon);

            try
            {
                con.Open();

                con.InfoMessage += (senderObj, args) =>
                {
                    foreach (SqlError error in args.Errors)
                    {
                        MessageBox.Show(error.Message, "Thông báo");
                        LoadBSXList();
                        ResetFormBSX();
                    }
                };
                string sBSX_ID = txtBBSX_id.Text;
                string skt_cccd = txtBBSX_cccd_kt.Text;

                string query = "EXEC pr_Them_BSX @BSX_ID, @kt_cccd, @return OUTPUT";
                SqlCommand cmd = new SqlCommand(query, con);

                cmd.Parameters.AddWithValue("@BSX_ID", sBSX_ID);
                cmd.Parameters.AddWithValue("@kt_cccd", skt_cccd);

                SqlParameter returnParam = new SqlParameter("@return", SqlDbType.Bit)
                {
                    Direction = ParameterDirection.Output
                };
                cmd.Parameters.Add(returnParam);

                cmd.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Xảy ra lỗi trong quá trình kết nối DB: " + ex.Message, "Thông báo");
            }
            finally
            {
                con.Close();
            }
        }

        private void btnCapNhat_BSX_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(sCon);

            try
            {
                con.Open();

                con.InfoMessage += (senderObj, args) =>
                {
                    foreach (SqlError error in args.Errors)
                    {
                        MessageBox.Show(error.Message, "Thông báo");
                        LoadBSXList(); 
                        ResetFormBSX(); 
                    }
                };

                string sBSX_ID = txtBBSX_id.Text;
                string skt_cccd = txtBBSX_cccd_kt.Text;

                string query = "EXEC pr_Sua_BSX @BSX_ID, @kt_cccd, @return OUTPUT";
                SqlCommand cmd = new SqlCommand(query, con);

                cmd.Parameters.AddWithValue("@BSX_ID", sBSX_ID);
                cmd.Parameters.AddWithValue("@kt_cccd", skt_cccd);

                SqlParameter returnParam = new SqlParameter("@return", SqlDbType.Bit)
                {
                    Direction = ParameterDirection.Output
                };
                cmd.Parameters.Add(returnParam);

                cmd.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Xảy ra lỗi trong quá trình kết nối DB: " + ex.Message, "Thông báo");
            }
            finally
            {
                con.Close();
            }
        }


        private void btnXoa_BSX_Click(object sender, EventArgs e)
        {
            DialogResult ret = MessageBox.Show("Bạn có chắc chắn muốn xoá không?", "Thông báo", MessageBoxButtons.OKCancel);
            if (ret == DialogResult.OK)
            {
                SqlConnection con = new SqlConnection(sCon);

                try
                {
                    con.Open();

                    con.InfoMessage += (senderObj, args) =>
                    {
                        foreach (SqlError error in args.Errors)
                        {
                            MessageBox.Show(error.Message, "Thông báo");
                            LoadBSXList();
                            ResetFormBSX();
                        }
                    };

                    string sBSX_ID = txtBBSX_id.Text;
                    string skt_cccd = txtBBSX_cccd_kt.Text;

                    string query = "EXEC pr_Xoa_BSX @BSX_ID, @kt_cccd, @return OUTPUT";
                    SqlCommand cmd = new SqlCommand(query, con);

                    cmd.Parameters.AddWithValue("@BSX_ID", sBSX_ID);
                    cmd.Parameters.AddWithValue("@kt_cccd", skt_cccd);

                    SqlParameter returnParam = new SqlParameter("@return", SqlDbType.Bit)
                    {
                        Direction = ParameterDirection.Output
                    };
                    cmd.Parameters.Add(returnParam);

                    cmd.ExecuteNonQuery();

                }
                catch (Exception ex)
                {
                    MessageBox.Show("Xảy ra lỗi trong quá trình kết nối DB: " + ex.Message, "Thông báo");
                }
                finally
                {
                    con.Close();
                }
            }
        }

        private void SearchBSX(string searchText)
        {
            using (SqlConnection con = new SqlConnection(sCon))
            {
                try
                {
                    con.Open();
                    string query = @"
            SELECT BSX_ID, kt_cccd
            FROM Bien_so_xe
            WHERE BSX_ID LIKE @SearchText
               OR kt_cccd LIKE @SearchText";

                    using (SqlCommand cmd = new SqlCommand(query, con))
                    {
                        cmd.Parameters.Add("@SearchText", SqlDbType.NVarChar).Value = "%" + searchText + "%";

                        SqlDataAdapter da = new SqlDataAdapter(cmd);
                        DataTable dt = new DataTable();
                        da.Fill(dt);

                        if (dt.Rows.Count > 0)
                        {
                            dtvgBSX.DataSource = dt;
                        }
                        else
                        {
                            MessageBox.Show("Không tìm thấy kết quả phù hợp.", "Thông báo");
                            dtvgBSX.DataSource = null;
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Lỗi khi tìm kiếm dữ liệu: " + ex.Message, "Thông báo");
                }
            }
        }

        private void btnfind_BSX_Click(object sender, EventArgs e)
        {
            string searchText = txtBfind_BSX.Text.Trim();

            if (string.IsNullOrEmpty(searchText))
            {
                MessageBox.Show("Vui lòng nhập thông tin cần tìm kiếm.", "Thông báo");
                LoadBSXList();
                return;
            }

            SearchBSX(searchText);
        }

        ///DỊCH VỤ-----------------------------------------------------------
        private void ResetFormDichVu()
        {
            txtBDV_id.Text = string.Empty;
            txtBDV_name.Text = string.Empty;
            txtBDV_price.Text = string.Empty;

            txtBDV_id.Enabled = true;

        }

        private void dtgvDichVu_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {

                txtBDV_id.Text = dtgvDichVu.Rows[e.RowIndex].Cells["DV_ID"].Value.ToString();
                txtBDV_name.Text = dtgvDichVu.Rows[e.RowIndex].Cells["dv_ten"].Value.ToString();
                txtBDV_price.Text = dtgvDichVu.Rows[e.RowIndex].Cells["dv_dongia"].Value.ToString();
                txtBDV_id.Enabled = false;
            }
        }
        private void SearchDichVu(string searchText)
        {
            using (SqlConnection con = new SqlConnection(sCon))
            {
                try
                {
                    con.Open();
                    string query = @"
            SELECT DV_ID, dv_ten, dv_dongia
            FROM Dich_vu
            WHERE DV_ID LIKE @SearchText
               OR dv_ten LIKE @SearchText
               OR dv_dongia LIKE @SearchText";

                    using (SqlCommand cmd = new SqlCommand(query, con))
                    {
                        cmd.Parameters.Add("@SearchText", SqlDbType.NVarChar).Value = "%" + searchText + "%";

                        SqlDataAdapter da = new SqlDataAdapter(cmd);
                        DataTable dt = new DataTable();
                        da.Fill(dt);

                        if (dt.Rows.Count > 0)
                        {
                            dtgvDichVu.DataSource = dt;
                        }
                        else
                        {
                            MessageBox.Show("Không tìm thấy kết quả phù hợp.", "Thông báo");
                            dtgvDichVu.DataSource = null;
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Lỗi khi tìm kiếm dữ liệu: " + ex.Message, "Thông báo");
                }
            }
        }

        private void btnDv_find_Click(object sender, EventArgs e)
        {
            string searchText = txtBDv_find.Text.Trim();

            if (string.IsNullOrEmpty(searchText))
            {
                MessageBox.Show("Vui lòng nhập thông tin cần tìm kiếm.", "Thông báo");
                LoadBSXList();
                return;
            }

            SearchDichVu(searchText);
        }
        private void btnThem_DV_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(sCon);

            try
            {
                con.Open();

                con.InfoMessage += (senderObj, args) =>
                {
                    foreach (SqlError error in args.Errors)
                    {
                        MessageBox.Show(error.Message, "Thông báo");
                        LoadDVList();
                        ResetFormDichVu();
                    }
                };

                string sDV_ID = txtBDV_id.Text;
                string sDV_name = txtBDV_name.Text;
                string sDv_price = txtBDV_price.Text;

                string query = "EXEC pro_Them_DV @DV_ID, @DV_Ten, @DV_Dongia, @return OUTPUT";
                SqlCommand cmd = new SqlCommand(query, con);

                cmd.Parameters.AddWithValue("@DV_ID", sDV_ID);
                cmd.Parameters.AddWithValue("@DV_Ten", sDV_name);
                cmd.Parameters.AddWithValue("@DV_Dongia", sDv_price);

                SqlParameter returnParam = new SqlParameter("@return", SqlDbType.Bit)
                {
                    Direction = ParameterDirection.Output
                };
                cmd.Parameters.Add(returnParam);

                cmd.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Xảy ra lỗi trong quá trình kết nối DB: " + ex.Message, "Thông báo");
            }
            finally
            {
                con.Close();
            }
        }

        private void btnCapnhat_DV_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(sCon);

            try
            {
                con.Open();

                con.InfoMessage += (senderObj, args) =>
                {
                    foreach (SqlError error in args.Errors)
                    {
                        MessageBox.Show(error.Message, "Thông báo");
                        LoadDVList();
                        ResetFormDichVu();
                    }
                };

                string sDV_ID = txtBDV_id.Text;
                string sDV_name = txtBDV_name.Text;
                string sDv_price = txtBDV_price.Text;

                string query = "EXEC pro_Sua_DV @DV_ID, @DV_Ten, @DV_Dongia, @return OUTPUT";
                SqlCommand cmd = new SqlCommand(query, con);

                cmd.Parameters.AddWithValue("@DV_ID", sDV_ID);
                cmd.Parameters.AddWithValue("@DV_Ten", sDV_name);
                cmd.Parameters.AddWithValue("@DV_Dongia", sDv_price);

                SqlParameter returnParam = new SqlParameter("@return", SqlDbType.Bit)
                {
                    Direction = ParameterDirection.Output
                };
                cmd.Parameters.Add(returnParam);

                cmd.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Xảy ra lỗi trong quá trình kết nối DB: " + ex.Message, "Thông báo");
            }
            finally
            {
                con.Close();
            }
        }

        private void btnXoa_DV_Click(object sender, EventArgs e)
        {
            DialogResult ret = MessageBox.Show("Bạn có chắc chắn muốn xoá không?", "Thông báo", MessageBoxButtons.OKCancel);

            if (ret == DialogResult.OK)
            {
                SqlConnection con = new SqlConnection(sCon);

                try
                {
                    con.Open();
                    con.InfoMessage += (senderObj, args) =>
                    {
                        foreach (SqlError error in args.Errors)
                        {
                            MessageBox.Show(error.Message, "Thông báo");
                            LoadDVList();
                            ResetFormDichVu();
                        }
                    };

                    string sDV_ID = txtBDV_id.Text;
                    string sDV_name = txtBDV_name.Text;
                    string sDv_price = txtBDV_price.Text;

                    string query = "EXEC pro_Xoa_DV @DV_ID, @DV_Ten, @DV_Dongia, @return OUTPUT";
                    SqlCommand cmd = new SqlCommand(query, con);

                    cmd.Parameters.AddWithValue("@DV_ID", sDV_ID);
                    cmd.Parameters.AddWithValue("@DV_Ten", sDV_name);
                    cmd.Parameters.AddWithValue("@DV_Dongia", sDv_price);

                    SqlParameter returnParam = new SqlParameter("@return", SqlDbType.Bit)
                    {
                        Direction = ParameterDirection.Output
                    };
                    cmd.Parameters.Add(returnParam);

                    cmd.ExecuteNonQuery();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Xảy ra lỗi trong quá trình kết nối DB: " + ex.Message, "Thông báo");
                }
                finally
                {
                    con.Close();
                }
            }
        }

        //------------------------------------------------------------------------------------------
        private void ResetFormTKKKT()
        {
            txtBTKKT_cccd.Text = string.Empty;
            txtBTKKKT_tenDN.Text = string.Empty;
            txtBTKKT_Matkhau.Text = string.Empty;

            txtBTKKKT_tenDN.Enabled = true;

        }

        private void btnThem_tkkkt_Click(object sender, EventArgs e)
        {
            // Sử dụng using để tự động đóng kết nối sau khi hoàn thành
            using (SqlConnection con = new SqlConnection(sCon))
            {
                try
                {
                    con.Open();

                    // Lắng nghe thông báo lỗi từ SQL Server
                    con.InfoMessage += (senderObj, args) =>
                    {
                        foreach (SqlError error in args.Errors)
                        {
                            MessageBox.Show(error.Message, "Thông báo");
                            LoadTKKhach_thueList();  // Giả sử bạn có phương thức này để tải lại danh sách
                            ResetFormTKKKT();  // Giả sử bạn có phương thức này để reset form
                        }
                    };

                    // Lấy giá trị từ các textbox
                    string sTKKT_cccd = txtBTKKT_cccd.Text;
                    string sTKKT_username = txtBTKKKT_tenDN.Text;
                    string sTKKT_password = txtBTKKT_Matkhau.Text;

                    // Gọi thủ tục để thêm tài khoản
                    SqlCommand cmd = new SqlCommand("pro_Them_TKKT", con)
                    {
                        CommandType = CommandType.StoredProcedure
                    };

                    // Thêm các tham số vào câu lệnh SQL
                    cmd.Parameters.AddWithValue("@TKKT_TenDN", sTKKT_username);
                    cmd.Parameters.AddWithValue("@TKKT_MK", sTKKT_password);
                    cmd.Parameters.AddWithValue("@kt_cccd", sTKKT_cccd);

                    // Thêm tham số đầu ra cho @return
                    SqlParameter returnParam = new SqlParameter("@return", SqlDbType.Bit)
                    {
                        Direction = ParameterDirection.Output
                    };
                    cmd.Parameters.Add(returnParam);

                    // Thực thi thủ tục SQL
                    cmd.ExecuteNonQuery();

                    // Kiểm tra kết quả trả về từ thủ tục
                    //if ((bool)returnParam.Value)
                    //{
                    //    MessageBox.Show("Thêm tài khoản thành công!", "Thông báo");
                    //    LoadTKKhach_thueList();  // Giả sử bạn có phương thức này để tải lại danh sách
                    //    ResetFormTKKKT();  // Giả sử bạn có phương thức này để reset form
                    //}
                    //else
                    //{
                    //    MessageBox.Show("Thêm tài khoản thất bại!", "Thông báo");
                    //    ResetFormTKKKT();  // Reset form nếu thất bại
                    //}
                }
                catch (SqlException sqlEx)
                {
                    MessageBox.Show("Lỗi SQL: " + sqlEx.Message, "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Lỗi hệ thống: " + ex.Message, "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }



        private void txtBTKKT_cccd_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnCapnhat_tkkt_Click(object sender, EventArgs e)
        {
            using (SqlConnection con = new SqlConnection(sCon))
            {
                try
                {
                    con.Open();

                    string sTKKT_cccd = txtBTKKT_cccd.Text;
                    string sTKKT_username = txtBTKKKT_tenDN.Text;
                    string sTKKT_password = txtBTKKT_Matkhau.Text;

                    // Kiểm tra nếu username không rỗng
                    if (string.IsNullOrEmpty(sTKKT_username))
                    {
                        MessageBox.Show("Tên đăng nhập không thể trống!", "Thông báo");
                        return;
                    }

                    string query = "UPDATE TK_Khach_Thue SET TKKT_MK = @Tkkt_passw, KT_CCCD = @kt_cccd WHERE TKKT_TenDN = @TKKT_username";
                    SqlCommand cmd = new SqlCommand(query, con);

                    // Thêm tham số vào câu lệnh
                    cmd.Parameters.AddWithValue("@TKKT_username", sTKKT_username);
                    cmd.Parameters.AddWithValue("@Tkkt_passw", sTKKT_password);
                    cmd.Parameters.AddWithValue("@kt_cccd", sTKKT_cccd);

                    try
                    {
                        int rowsAffected = cmd.ExecuteNonQuery();

                        // Kiểm tra nếu có bản ghi được cập nhật
                        if (rowsAffected > 0)
                        {
                            MessageBox.Show("Cập nhật thành công!", "Thông báo");
                            LoadTKKhach_thueList();
                            ResetFormTKKKT();
                        }
                        else
                        {
                            MessageBox.Show("Không tìm thấy tài khoản với tên đăng nhập này!", "Thông báo");
                            ResetFormTKKKT();
                        }
                    }
                    catch (SqlException sqlEx)
                    {
                        MessageBox.Show("Lỗi SQL: " + sqlEx.Message, "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Xảy ra lỗi trong quá trình kết nối DB: " + ex.Message, "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void dtgvTKKT_CellClick(object sender, DataGridViewCellEventArgs e)
        {

            if (e.RowIndex >= 0)
            {

                DataGridViewRow selectedRow = dtgvTKKT.Rows[e.RowIndex];

                txtBTKKT_cccd.Text = selectedRow.Cells["kt_cccd"].Value?.ToString();
                txtBTKKKT_tenDN.Text = selectedRow.Cells["TKKT_TenDN"].Value?.ToString();
                txtBTKKT_Matkhau.Text = selectedRow.Cells["TKKT_MK"].Value?.ToString();

                txtBTKKKT_tenDN.Enabled = false;
            }

        }

        private void btnXoa_tkkt_Click(object sender, EventArgs e)
        {
            DialogResult ret = MessageBox.Show("Bạn có chắc chắn muốn xoá không?", "Thông báo", MessageBoxButtons.OKCancel);
            if (ret == DialogResult.OK)
            {
                SqlConnection con = new SqlConnection(sCon);
                try
                {
                    con.Open();
                    string sTKKT_username = txtBTKKKT_tenDN.Text;


                    string query = "delete TK_khach_thue where tkkt_tenDN= @TKKT_username";
                    SqlCommand cmd = new SqlCommand(query, con);
                    cmd.Parameters.AddWithValue("@TKKT_username", sTKKT_username);

                    try
                    {
                        cmd.ExecuteNonQuery();
                        MessageBox.Show("Xoá thành công!", "Thông báo");
                        LoadTKKhach_thueList();
                        ResetFormTKKKT();
                    }
                    catch
                    {
                        MessageBox.Show("Xoá thất bại!", "Thông báo");
                        ResetFormTKKKT();
                    }

                }
                catch (Exception ex)
                {
                    MessageBox.Show("Xảy ra lỗi trong quá trình kết nối DB", "Thông báo");
                }
                finally
                {
                    con.Close();
                }
            }
        }
        //--------------------------------------------------------------------------------------------
        private void ResetFormHopDong()
        {
            txtBHD_ID.Text = string.Empty;
            txtBHD_cccd_kt.Text = string.Empty;
            txtBHD_cccd_ct.Text = string.Empty;
            txtBHD_p_id.Text = string.Empty;
            txtBHD_tiendatcoc.Text = string.Empty;

            dateTimePickerHD_daystart.Value = DateTime.Now;
            dateTimePickerHD_dayend.Value = DateTime.Now;

            numUDHD_tinhtrang.Value = numUDHD_tinhtrang.Minimum;
            txtBHD_ID.Enabled = true;
        }

        private void btnThem_HD_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(sCon);
            try
            {
                con.Open();
                string sHD_ID = txtBHD_ID.Text;
                string sHD_cccd_kt = txtBHD_cccd_kt.Text;
                string sHD_cccd_ct = txtBHD_cccd_ct.Text;
                string sHD_p_id = txtBHD_p_id.Text;
                decimal sHD_price = decimal.Parse(txtBHD_tiendatcoc.Text.Trim());
                string sHD_daystart = dateTimePickerHD_daystart.Value.ToString("yyyy-MM-dd");
                string sHD_dayend = dateTimePickerHD_dayend.Value.ToString("yyyy-MM-dd");
                int sHD_tinhtrang = (int)numUDHD_tinhtrang.Value;


                string query = "insert into Hop_dong (HDong_ID, HDong_TinhTrang, ct_cccd, kt_cccd, p_id, HDong_NgayBatDau, HDong_NgayKetThuc, HDong_TienDatCoc) values (@HD_ID,@HD_TinhTrang, @HD_CCCD_CT, @HD_CCCD_KT, @P_ID,@HD_NgayBatDau, @HD_NgayKetThuc, @HD_TienDatCoc  )";
                SqlCommand cmd = new SqlCommand(query, con);
                cmd.Parameters.AddWithValue("@HD_ID", sHD_ID);
                cmd.Parameters.AddWithValue("@HD_TinhTrang", sHD_tinhtrang);
                cmd.Parameters.AddWithValue("@HD_CCCD_KT", sHD_cccd_kt);
                cmd.Parameters.AddWithValue("@HD_CCCD_CT", sHD_cccd_ct);
                cmd.Parameters.AddWithValue("@P_ID", sHD_p_id);

                cmd.Parameters.AddWithValue("@HD_NgayBatDau", sHD_daystart);
                cmd.Parameters.AddWithValue("@HD_NgayKetThuc", sHD_dayend);
                cmd.Parameters.AddWithValue("@HD_TienDatCoc", sHD_price);


                try
                {
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Thêm dữ liệu thành công!", "Thông báo");
                    LoadHop_DongList();
                    ResetFormHopDong();
                }
                catch
                {
                    MessageBox.Show("Thêm dữ liệu thất bại!", "Thông báo");
                    ResetFormHopDong();
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show("Xảy ra lỗi trong quá trình kết nối DB", "Thông báo");
            }
            finally
            {
                con.Close();
            }
        }

        private void dtvgHopDong_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {

                DataGridViewRow selectedRow = dtvgHopDong.Rows[e.RowIndex];

                txtBHD_ID.Text = selectedRow.Cells["HDong_ID"]?.Value?.ToString() ?? "";
                txtBHD_cccd_ct.Text = selectedRow.Cells["ct_cccd"]?.Value?.ToString() ?? "";
                txtBHD_cccd_kt.Text = selectedRow.Cells["kt_cccd"]?.Value?.ToString() ?? "";
                txtBHD_p_id.Text = selectedRow.Cells["p_id"]?.Value?.ToString() ?? "";
                txtBHD_tiendatcoc.Text = selectedRow.Cells["HDong_TienDatCoc"]?.Value?.ToString() ?? "";

                dateTimePickerHD_daystart.Value = selectedRow.Cells["HDong_NgayBatDau"]?.Value != DBNull.Value ? Convert.ToDateTime(selectedRow.Cells["HDong_NgayBatDau"].Value) : DateTime.Now;
                dateTimePickerHD_dayend.Value = selectedRow.Cells["HDong_NgayKetThuc"]?.Value != DBNull.Value ? Convert.ToDateTime(selectedRow.Cells["HDong_NgayKetThuc"].Value) : DateTime.Now;

                if (selectedRow.Cells["HDong_TinhTrang"].Value != DBNull.Value)
                {
                    numUDHD_tinhtrang.Value = Convert.ToInt32(selectedRow.Cells["HDong_TinhTrang"].Value);
                }
                else
                {
                    numUDHD_tinhtrang.Value = 0;
                }

                txtBHD_ID.Enabled = false;
            }
        }

        private void btnCapnhat_HD_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(sCon);
            try
            {
                con.Open();
                string sHD_ID = txtBHD_ID.Text;
                string sHD_cccd_kt = txtBHD_cccd_kt.Text;
                string sHD_cccd_ct = txtBHD_cccd_ct.Text;
                string sHD_p_id = txtBHD_p_id.Text;
                decimal sHD_price = decimal.Parse(txtBHD_tiendatcoc.Text.Trim());
                string sHD_daystart = dateTimePickerHD_daystart.Value.ToString("yyyy-MM-dd");
                string sHD_dayend = dateTimePickerHD_dayend.Value.ToString("yyyy-MM-dd");
                int sHD_tinhtrang = (int)numUDHD_tinhtrang.Value;


                string query = "UPDATE Hop_dong SET " +
                       "HDong_TinhTrang = @HD_TinhTrang, " +
                       "ct_cccd = @HD_CCCD_CT, " +
                       "kt_cccd = @HD_CCCD_KT, " +
                       "p_id = @P_ID, " +
                       "HDong_NgayBatDau = @HD_NgayBatDau, " +
                       "HDong_NgayKetThuc = @HD_NgayKetThuc, " +
                       "HDong_TienDatCoc = @HD_TienDatCoc " +
                       "WHERE HDong_ID = @HD_ID";
                SqlCommand cmd = new SqlCommand(query, con);
                cmd.Parameters.AddWithValue("@HD_ID", sHD_ID);
                cmd.Parameters.AddWithValue("@HD_TinhTrang", sHD_tinhtrang);
                cmd.Parameters.AddWithValue("@HD_CCCD_KT", sHD_cccd_kt);
                cmd.Parameters.AddWithValue("@HD_CCCD_CT", sHD_cccd_ct);
                cmd.Parameters.AddWithValue("@P_ID", sHD_p_id);

                cmd.Parameters.AddWithValue("@HD_NgayBatDau", sHD_daystart);
                cmd.Parameters.AddWithValue("@HD_NgayKetThuc", sHD_dayend);
                cmd.Parameters.AddWithValue("@HD_TienDatCoc", sHD_price);


                try
                {
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Cập nhật thành công!", "Thông báo");
                    LoadHop_DongList();
                    ResetFormHopDong();
                }
                catch
                {
                    MessageBox.Show("Cập nhật thất bại!", "Thông báo");
                    ResetFormHopDong();
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show("Xảy ra lỗi trong quá trình kết nối DB", "Thông báo");
            }
            finally
            {
                con.Close();
            }
        }
        //------------------------------------------
        private void ResetFormKT()
        {
            txtBKTcccd.Text = string.Empty;
            txtKT_name.Text = string.Empty;
            txtBKTphone.Text = string.Empty;
            rtxtBKTaddress.Text = string.Empty;

            rBtnKT_sex_1.Checked = false;
            rBtnKT_sex_0.Checked = false;

            txtBKTcccd.Enabled = true;
        }

        private void btnThem_KT_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(sCon);
            try
            {
                con.Open();
                string sKT_cccd = txtBKTcccd.Text;
                string sKT_name = txtKT_name.Text;
                string sKT_phone = txtBKTphone.Text;
                int iKT_sex = 0;
                if (rBtnKT_sex_1.Checked == true)
                {
                    iKT_sex = 1;
                }

                string sKT_hokhau = rtxtBKTaddress.Text;

                string query = "INSERT INTO Khach_Thue (KT_CCCD, KT_Ten, KT_SDT, KT_GioiTinh, KT_HoKhau) " +
                       "VALUES (@KT_CCCD, @KT_Ten, @KT_SDT, @KT_GioiTinh, @KT_HoKhau)";
                SqlCommand cmd = new SqlCommand(query, con);

                cmd.Parameters.AddWithValue("@KT_CCCD", sKT_cccd);
                cmd.Parameters.AddWithValue("@KT_Ten", sKT_name);
                cmd.Parameters.AddWithValue("@KT_SDT", sKT_phone);
                cmd.Parameters.AddWithValue("@KT_GioiTinh", iKT_sex);
                cmd.Parameters.AddWithValue("@KT_HoKhau", sKT_hokhau);


                try
                {
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Thêm dữ liệu thành công!", "Thông báo");
                    LoadKhach_ThueList();
                    ResetFormKT();
                }
                catch
                {
                    MessageBox.Show("Thêm dữ liệu thất bại!", "Thông báo");
                    ResetFormKT();
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show("Xảy ra lỗi trong quá trình kết nối DB", "Thông báo");
            }
            finally
            {
                con.Close();
            }
        }

        private void dtgvKhach_Thue_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {

                DataGridViewRow selectedRow = dtgvKhach_Thue.Rows[e.RowIndex];

                txtBKTcccd.Text = selectedRow.Cells["KT_CCCD"]?.Value?.ToString() ?? "";
                txtKT_name.Text = selectedRow.Cells["KT_Ten"]?.Value?.ToString() ?? "";
                txtBKTphone.Text = selectedRow.Cells["KT_SDT"]?.Value?.ToString() ?? "";

                if (selectedRow.Cells["KT_GioiTinh"].Value != DBNull.Value)
                {
                    int gioiTinh = Convert.ToInt32(selectedRow.Cells["KT_GioiTinh"].Value);
                    if (gioiTinh == 1)
                    {
                        rBtnKT_sex_1.Checked = true;
                    }
                    else
                    {
                        rBtnKT_sex_0.Checked = true;
                    }
                }

                rtxtBKTaddress.Text = selectedRow.Cells["KT_HoKhau"]?.Value?.ToString() ?? "";

                txtBKTcccd.Enabled = false;
            }
        }

        private void btnCapNhat_KT_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(sCon);
            try
            {
                con.Open();
                string sKT_cccd = txtBKTcccd.Text;
                string sKT_name = txtKT_name.Text;
                string sKT_phone = txtBKTphone.Text;
                int iKT_sex = 0;
                if (rBtnKT_sex_1.Checked == true)
                {
                    iKT_sex = 1;
                }

                string sKT_hokhau = rtxtBKTaddress.Text;

                string query = "UPDATE Khach_Thue " +
                       "SET KT_Ten = @KT_Ten, KT_SDT = @KT_SDT, KT_GioiTinh = @KT_GioiTinh, KT_HoKhau = @KT_HoKhau " +
                       "WHERE KT_CCCD = @KT_CCCD";
                SqlCommand cmd = new SqlCommand(query, con);

                cmd.Parameters.AddWithValue("@KT_CCCD", sKT_cccd);
                cmd.Parameters.AddWithValue("@KT_Ten", sKT_name);
                cmd.Parameters.AddWithValue("@KT_SDT", sKT_phone);
                cmd.Parameters.AddWithValue("@KT_GioiTinh", iKT_sex);
                cmd.Parameters.AddWithValue("@KT_HoKhau", sKT_hokhau);


                try
                {
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Cập nhật thành công!", "Thông báo");
                    LoadKhach_ThueList();
                    ResetFormKT();
                }
                catch
                {
                    MessageBox.Show("Cập nhật thất bại!", "Thông báo");
                    ResetFormKT();
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show("Xảy ra lỗi trong quá trình kết nối DB", "Thông báo");
            }
            finally
            {
                con.Close();
            }
        }

        private void btnXoa_KT_Click(object sender, EventArgs e)
        {
            DialogResult ret = MessageBox.Show("Bạn có chắc chắn muốn xoá không?", "Thông báo", MessageBoxButtons.OKCancel);
            if (ret == DialogResult.OK)
            {
                SqlConnection con = new SqlConnection(sCon);
                try
                {
                    con.Open();
                    string sKT_cccd = txtBKTcccd.Text;


                    string query = "delete khach_thue where kt_cccd= @KT_CCCD";
                    SqlCommand cmd = new SqlCommand(query, con);
                    cmd.Parameters.AddWithValue("@KT_CCCD", sKT_cccd);

                    try
                    {
                        cmd.ExecuteNonQuery();
                        MessageBox.Show("Xoá thành công!", "Thông báo");
                        LoadKhach_ThueList();
                        ResetFormKT();
                    }
                    catch
                    {
                        MessageBox.Show("Xoá thất bại!", "Thông báo");
                        ResetFormKT();
                    }

                }
                catch (Exception ex)
                {
                    MessageBox.Show("Xảy ra lỗi trong quá trình kết nối DB", "Thông báo");
                }
                finally
                {
                    con.Close();
                }
            }
        }

        private void btnFind_KT_Click(object sender, EventArgs e)
        {
            string searchText = txtFind_KT.Text.Trim();

            if (string.IsNullOrEmpty(searchText))
            {
                MessageBox.Show("Vui lòng nhập thông tin cần tìm kiếm.", "Thông báo");
                LoadKhach_ThueList();
                return;
            }

            SearchKhachThue(searchText);
        }

        private void SearchKhachThue(string searchText)
        {
            using (SqlConnection con = new SqlConnection(sCon))
            {
                try
                {
                    con.Open();

                    string query = @"
                SELECT KT_CCCD, KT_Ten, KT_SDT, KT_GioiTinh, KT_HoKhau 
                FROM Khach_Thue 
                WHERE KT_CCCD LIKE @SearchText 
                   OR KT_Ten LIKE @SearchText 
                   OR KT_SDT LIKE @SearchText 
                   OR KT_HoKhau LIKE @SearchText";

                    using (SqlCommand cmd = new SqlCommand(query, con))
                    {
                        cmd.Parameters.Add("@SearchText", SqlDbType.NVarChar).Value = "%" + searchText + "%";

                        SqlDataAdapter da = new SqlDataAdapter(cmd);
                        DataTable dt = new DataTable();
                        da.Fill(dt);

                        if (dt.Rows.Count > 0)
                        {
                            dtgvKhach_Thue.DataSource = dt;
                        }
                        else
                        {
                            MessageBox.Show("Không tìm thấy kết quả phù hợp.", "Thông báo");
                            dtgvKhach_Thue.DataSource = null;
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Lỗi khi tìm kiếm dữ liệu: " + ex.Message, "Thông báo");
                }
            }
        }


        private void SearchPhongTro(string searchText)
        {
            using (SqlConnection con = new SqlConnection(sCon))
            {
                try
                {
                    con.Open();

                    string query = @"
                SELECT P_ID, P_SoLuong, P_GiaPhong, P_TinhTrang
                FROM Phong_Tro
                WHERE P_ID LIKE @SearchText
                   OR P_SoLuong LIKE @SearchText
                   OR P_GiaPhong LIKE @SearchText
                   OR P_TinhTrang LIKE @SearchText";

                    using (SqlCommand cmd = new SqlCommand(query, con))
                    {
                        cmd.Parameters.Add("@SearchText", SqlDbType.NVarChar).Value = "%" + searchText + "%";

                        SqlDataAdapter da = new SqlDataAdapter(cmd);
                        DataTable dt = new DataTable();
                        da.Fill(dt);

                        if (dt.Rows.Count > 0)
                        {
                            dtgvPhong_tro.DataSource = dt;
                        }
                        else
                        {
                            MessageBox.Show("Không tìm thấy kết quả phù hợp.", "Thông báo");
                            dtgvPhong_tro.DataSource = null;
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Lỗi khi tìm kiếm dữ liệu: " + ex.Message, "Thông báo");
                }
            }
        }

        private void btnSearch_P_Click(object sender, EventArgs e)
        {
            string searchText = txtBfind_P.Text.Trim();

            if (string.IsNullOrEmpty(searchText))
            {
                MessageBox.Show("Vui lòng nhập thông tin cần tìm kiếm.", "Thông báo");
                LoadPhong_TroList();
                return;
            }

            SearchPhongTro(searchText);
        }
        private void SearchHopDong(string searchText)
        {
            using (SqlConnection con = new SqlConnection(sCon))
            {
                try
                {
                    con.Open();
                    string query = @"
                        SELECT HDong_ID, HDong_TinhTrang, ct_cccd, kt_cccd, p_id, HDong_NgayBatDau, HDong_NgayKetThuc, HDong_TienDatCoc
                        FROM Hop_dong
                        WHERE HDong_ID LIKE @SearchText
                           OR ct_cccd LIKE @SearchText
                           OR kt_cccd LIKE @SearchText
                           OR p_id LIKE @SearchText
                           OR HDong_TienDatCoc LIKE @SearchText
                           OR HDong_TinhTrang LIKE @SearchText";

                    using (SqlCommand cmd = new SqlCommand(query, con))
                    {
                        cmd.Parameters.Add("@SearchText", SqlDbType.NVarChar).Value = "%" + searchText + "%";

                        SqlDataAdapter da = new SqlDataAdapter(cmd);
                        DataTable dt = new DataTable();
                        da.Fill(dt);

                        if (dt.Rows.Count > 0)
                        {
                            dtvgHopDong.DataSource = dt;
                        }
                        else
                        {
                            MessageBox.Show("Không tìm thấy kết quả phù hợp.", "Thông báo");
                            dtvgHopDong.DataSource = null;
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Lỗi khi tìm kiếm dữ liệu: " + ex.Message, "Thông báo");
                }
            }
        }

        private void btnFind_HD_Click(object sender, EventArgs e)
        {
            string searchText = txtBHD_find.Text.Trim();

            if (string.IsNullOrEmpty(searchText))
            {
                MessageBox.Show("Vui lòng nhập thông tin cần tìm kiếm.", "Thông báo");
                LoadHop_DongList();
                return;
            }

            SearchHopDong(searchText);
        }
        
        //TÀI KHOẢN KHÁCH THUÊ
        private void SearchTKKhachThue(string searchText)
        {
            using (SqlConnection con = new SqlConnection(sCon))
            {
                try
                {
                    con.Open();

                    string query = @"
            SELECT TKKT_TenDN, TKKT_MK, kt_cccd
            FROM TK_Khach_Thue
            WHERE TKKT_TenDN LIKE @SearchText
               OR TKKT_MK LIKE @SearchText
               OR kt_cccd LIKE @SearchText";

                    using (SqlCommand cmd = new SqlCommand(query, con))
                    {
                        cmd.Parameters.Add("@SearchText", SqlDbType.NVarChar).Value = "%" + searchText + "%";

                        SqlDataAdapter da = new SqlDataAdapter(cmd);
                        DataTable dt = new DataTable();
                        da.Fill(dt);

                        if (dt.Rows.Count > 0)
                        {
                            dtgvTKKT.DataSource = dt;
                        }
                        else
                        {
                            MessageBox.Show("Không tìm thấy dữ liệu phù hợp.", "Thông báo");
                            dtgvTKKT.DataSource = null;
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Lỗi khi tìm kiếm dữ liệu: " + ex.Message, "Thông báo");
                }
            }
        }

        private void btnfind_tkkt_Click_1(object sender, EventArgs e)
        {
            string searchText = txtBfind_TKKT.Text.Trim();

            if (string.IsNullOrEmpty(searchText))
            {
                MessageBox.Show("Vui lòng nhập thông tin cần tìm kiếm.", "Thông báo");
                LoadTKKhach_thueList();
                return;
            }

            SearchTKKhachThue(searchText);
        }

//

        private void LoadcomboBoxRoomHoaDon_idList()
        {
            SqlConnection con = new SqlConnection(sCon);
            try
            {
                con.Open();

                string query = "SELECT hdon_id FROM hoa_don WHERE hdon_TinhTrang = 1";
                SqlCommand command = new SqlCommand(query, con);

                DataTable data = new DataTable();
                SqlDataAdapter adapter = new SqlDataAdapter(command);
                adapter.Fill(data);

                comboBoxRoomHoaDon_id.DataSource = data;

                comboBoxRoomHoaDon_id.DisplayMember = "hdon_id";
                comboBoxRoomHoaDon_id.ValueMember = "hdon_id";
                comboBoxRoomHoaDon_id.SelectedIndex = -1;

            }
            catch (Exception ex)
            {
                MessageBox.Show($"Xảy ra lỗi: {ex.Message}", "Thông báo");
            }
            finally
            {
                con.Close();
            }
        }


        private void LoadcomboBoxServicesHoaDon_dv_idList()
        {
            SqlConnection con = new SqlConnection(sCon);
            try
            {
                con.Open();

                string query = "SELECT dv_id FROM Dich_Vu";
                SqlCommand command = new SqlCommand(query, con);

                DataTable data = new DataTable();
                SqlDataAdapter adapter = new SqlDataAdapter(command);
                adapter.Fill(data);

                comboBoxServicesHoaDon_dv_id.DataSource = data;

                comboBoxServicesHoaDon_dv_id.DisplayMember = "dv_id";
                comboBoxServicesHoaDon_dv_id.ValueMember = "dv_id";

                comboBoxServicesHoaDon_dv_id.SelectedIndex = -1;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Xảy ra lỗi: {ex.Message}", "Thông báo");
            }
            finally
            {
                con.Close();
            }
        }

        private void ConfigureListViewHoaDon()
        {
            listViewHoaDon.View = View.Details;

            listViewHoaDon.Columns.Add("Mã hóa đơn", 100);
            listViewHoaDon.Columns.Add("Mã Dịch vụ", 100);
            listViewHoaDon.Columns.Add("Ngày", 100);
            listViewHoaDon.Columns.Add("Số cũ", 100);
            listViewHoaDon.Columns.Add("Số mới", 100);
            listViewHoaDon.Columns.Add("Tiền", 100);
        }

        private void btn_them_listView_Click(object sender, EventArgs e)
        {

            string maHoaDon = comboBoxRoomHoaDon_id.SelectedValue != null ? comboBoxRoomHoaDon_id.SelectedValue.ToString() : "Chưa chọn phòng";
            string dichVu = comboBoxServicesHoaDon_dv_id.SelectedValue != null ? comboBoxServicesHoaDon_dv_id.SelectedValue.ToString() : "Chưa chọn dịch vụ";

            DateTime ngay = dateTimePickerHoaDon_date.Value;
            string soCu = string.IsNullOrEmpty(txtBHoadon_socu.Text) ? "0" : txtBHoadon_socu.Text;
            string soMoi = string.IsNullOrEmpty(txtBHoadon_somoi.Text) ? "0" : txtBHoadon_somoi.Text;

            decimal tien = 0;
            decimal donGia = 0;

            if (dichVu == "DV00001")
            {

                donGia = GetDonGiaFromtableDV(dichVu);
                if (decimal.TryParse(soCu, out decimal soCuDecimal) && decimal.TryParse(soMoi, out decimal soMoiDecimal))
                {
                    tien = donGia * (soMoiDecimal - soCuDecimal);
                }
            }
            else
            {
                donGia = GetDonGiaFromtableDV(dichVu);
                if (decimal.TryParse(soCu, out decimal soCuDecimal) && decimal.TryParse(soMoi, out decimal soMoiDecimal))
                {
                    tien = donGia;
                }
            }

            Console.WriteLine($"Mã hóa đơn: {maHoaDon}, Dịch vụ: {dichVu}, Ngày: {ngay.ToString("yyyy-MM-dd")}, Số cũ: {soCu}, Số mới: {soMoi}, Tiền: {tien}");

            ListViewItem item = new ListViewItem(maHoaDon);
            item.SubItems.Add(dichVu);
            item.SubItems.Add(ngay.ToString("yyyy-MM-dd"));
            item.SubItems.Add(soCu);
            item.SubItems.Add(soMoi);
            item.SubItems.Add(tien.ToString("C"));

            listViewHoaDon.Items.Add(item);
            ResetFormHDonChitiet();
        }

        private void ResetFormHDonChitiet()
        {
            comboBoxRoomHoaDon_id.SelectedIndex = -1;
            comboBoxRoomHoaDon_id.Text = "";
            comboBoxRoomHoaDon_id.Refresh();

            comboBoxServicesHoaDon_dv_id.SelectedIndex = -1;
            comboBoxServicesHoaDon_dv_id.Text = "";
            comboBoxServicesHoaDon_dv_id.Refresh();

            txtBHoadon_socu.Text = string.Empty;
            txtBHoadon_somoi.Text = string.Empty;
            dateTimePickerHoaDon_date.Value = DateTime.Now;

            comboBoxRoomHoaDon_id.Enabled = true;
            comboBoxServicesHoaDon_dv_id.Enabled = true;
        }

        private decimal GetDonGiaFromtableDV(string dv_id)
        {
            decimal donGia = 0;
            SqlConnection con = new SqlConnection(sCon);
            try
            {
                con.Open();
                string query = "SELECT dv_dongia FROM Dich_Vu WHERE dv_id = @dv_id";
                SqlCommand cmd = new SqlCommand(query, con);
                cmd.Parameters.AddWithValue("@dv_id", dv_id);

                object result = cmd.ExecuteScalar();
                if (result != DBNull.Value)
                {
                    donGia = Convert.ToDecimal(result);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Lỗi khi lấy đơn giá dịch vụ: {ex.Message}");
            }
            finally
            {
                con.Close();
            }
            return donGia;
        }
        private void XoaTatCaListView()
        {
            listViewHoaDon.Items.Clear();
        }

        private void btnThem_Hoadon_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(sCon);

            try
            {
                con.Open();

                foreach (ListViewItem item in listViewHoaDon.Items)
                {
                    string maHoaDon = item.SubItems[0].Text;
                    string dichVu = item.SubItems[1].Text;
                    string ngay = item.SubItems[2].Text;
                    string soCu = item.SubItems[3].Text;
                    string soMoi = item.SubItems[4].Text;
                    string query = @"
                INSERT INTO HDon_Chi_Tiet (hdon_id, dv_id, HdonCT_NgayThangNam, HdonCT_SoCu, HdonCT_SoMoi) 
                VALUES (@hdon_id, @dv_id, @HdonCT_NgayThangNam, @HdonCT_SoCu, @HdonCT_SoMoi)";

                    SqlCommand cmd = new SqlCommand(query, con);

                    cmd.Parameters.AddWithValue("@hdon_id", maHoaDon);
                    cmd.Parameters.AddWithValue("@dv_id", dichVu);
                    cmd.Parameters.AddWithValue("@HdonCT_NgayThangNam", DateTime.Parse(ngay));
                    cmd.Parameters.AddWithValue("@HdonCT_SoCu", decimal.Parse(soCu));
                    cmd.Parameters.AddWithValue("@HdonCT_SoMoi", decimal.Parse(soMoi));

                    try
                    {
                        cmd.ExecuteNonQuery();
                        MessageBox.Show("Thêm dữ liệu thành công!", "Thông báo");
                        LoadHDon_ChiTietList();
                        XoaTatCaListView();

                    }
                    catch
                    {
                        MessageBox.Show("Thêm dữ liệu thất bại!", "Thông báo");
                    }

                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Xảy ra lỗi trong quá trình kết nối DB", "Thông báo");
                ResetFormHDonChitiet();
            }
            finally
            {
                con.Close();
            }
        }

        private void btnCapnhap_hoadon_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(sCon);

            try
            {
                con.Open();

                string sHD_ID = comboBoxRoomHoaDon_id.Text;
                string sHD_DV_id = comboBoxServicesHoaDon_dv_id.Text;
                string sHD_date = dateTimePickerHoaDon_date.Value.ToString("yyyy-MM-dd");
                string sHD_socu = txtBHoadon_socu.Text;
                string sHD_somoi = txtBHoadon_somoi.Text;

                string query = @"
                                UPDATE HDon_Chi_Tiet 
                                SET HdonCT_NgayThangNam=@HdonCT_NgayThangNam, HdonCT_SoCu=@HdonCT_SoCu, HdonCT_SoMoi=@HdonCT_SoMoi
                                WHERE hdon_id = @hdon_id AND dv_id = @dv_id;";

                SqlCommand cmd = new SqlCommand(query, con);
                cmd.Parameters.AddWithValue("@hdon_id", sHD_ID);
                cmd.Parameters.AddWithValue("@HdonCT_NgayThangNam", sHD_date);
                cmd.Parameters.AddWithValue("@HdonCT_SoCu", decimal.Parse(sHD_socu));
                cmd.Parameters.AddWithValue("@HdonCT_SoMoi", decimal.Parse(sHD_somoi));
                cmd.Parameters.AddWithValue("@dv_id", sHD_DV_id);

                cmd.ExecuteNonQuery();
                MessageBox.Show("Cập nhật thành công!", "Thông báo");
                LoadHDon_ChiTietList();
                ResetFormHDonChitiet();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Cập nhật thất bại! Lỗi: " + ex.Message, "Thông báo");
                ResetFormHDonChitiet();
            }
            finally
            {
                con.Close();
            }
        }



        private void dataGridViewHoadonCT_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                comboBoxRoomHoaDon_id.Text = dataGridViewHoadonCT.Rows[e.RowIndex].Cells["hdon_id"].Value != DBNull.Value
                    ? dataGridViewHoadonCT.Rows[e.RowIndex].Cells["hdon_id"].Value.ToString()
                    : string.Empty;

                comboBoxServicesHoaDon_dv_id.Text = dataGridViewHoadonCT.Rows[e.RowIndex].Cells["dv_id"].Value != DBNull.Value
                    ? dataGridViewHoadonCT.Rows[e.RowIndex].Cells["dv_id"].Value.ToString()
                    : string.Empty;

                dateTimePickerHoaDon_date.Value = dataGridViewHoadonCT.Rows[e.RowIndex].Cells["HdonCT_NgayThangNam"].Value != DBNull.Value
                    ? Convert.ToDateTime(dataGridViewHoadonCT.Rows[e.RowIndex].Cells["HdonCT_NgayThangNam"].Value)
                    : DateTime.Now;

                txtBHoadon_socu.Text = dataGridViewHoadonCT.Rows[e.RowIndex].Cells["HdonCT_SoCu"].Value != DBNull.Value
                    ? dataGridViewHoadonCT.Rows[e.RowIndex].Cells["HdonCT_SoCu"].Value.ToString()
                    : string.Empty;

                txtBHoadon_somoi.Text = dataGridViewHoadonCT.Rows[e.RowIndex].Cells["HdonCT_SoMoi"].Value != DBNull.Value
                    ? dataGridViewHoadonCT.Rows[e.RowIndex].Cells["HdonCT_SoMoi"].Value.ToString()
                    : string.Empty;

                comboBoxRoomHoaDon_id.Enabled = false;
                comboBoxServicesHoaDon_dv_id.Enabled = false;
            }
        }

        private void btnXoa_Hoadon_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(comboBoxRoomHoaDon_id.Text) || string.IsNullOrEmpty(comboBoxServicesHoaDon_dv_id.Text))
            {
                MessageBox.Show("Vui lòng chọn hóa đơn cần xóa!", "Thông báo");
                return;
            }

            DialogResult ret = MessageBox.Show("Bạn có chắc chắn muốn xoá không?", "Thông báo", MessageBoxButtons.OKCancel);
            if (ret == DialogResult.OK)
            {
                SqlConnection con = new SqlConnection(sCon);
                try
                {
                    con.Open();
                    string sHD_ID = comboBoxRoomHoaDon_id.Text;
                    string sHD_DV_id = comboBoxServicesHoaDon_dv_id.Text;

                    string query = @"
            DELETE FROM HDon_Chi_Tiet 
            WHERE hdon_id = @hdon_id AND dv_id = @dv_id;";

                    SqlCommand cmd = new SqlCommand(query, con);
                    cmd.Parameters.AddWithValue("@hdon_id", sHD_ID);
                    cmd.Parameters.AddWithValue("@dv_id", sHD_DV_id);

                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Xóa thành công!", "Thông báo");
                    LoadHDon_ChiTietList();
                    ResetFormHDonChitiet();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Xóa thất bại! Lỗi: " + ex.Message, "Thông báo");
                    ResetFormHDonChitiet();

                }
                finally
                {
                    con.Close();
                }
            }
        }



        private void SearchHoaDonChiTiet(string searchText)
        {
            using (SqlConnection con = new SqlConnection(sCon))
            {
                try
                {
                    con.Open();

                    string query = @"
                SELECT hdon_id, dv_id, HdonCT_NgayThangNam, HdonCT_SoCu, HdonCT_SoMoi
                FROM hdon_chi_tiet
                WHERE hdon_id LIKE @SearchText
                   OR dv_id LIKE @SearchText";

                    using (SqlCommand cmd = new SqlCommand(query, con))
                    {
                        cmd.Parameters.Add("@SearchText", SqlDbType.NVarChar).Value = "%" + searchText + "%";

                        SqlDataAdapter da = new SqlDataAdapter(cmd);
                        DataTable dt = new DataTable();
                        da.Fill(dt);

                        if (dt.Rows.Count > 0)
                        {
                            dataGridViewHoadonCT.DataSource = dt;
                        }
                        else
                        {
                            MessageBox.Show("Không tìm thấy kết quả phù hợp.", "Thông báo");
                            dataGridViewHoadonCT.DataSource = null;
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Lỗi khi tìm kiếm dữ liệu: " + ex.Message, "Thông báo");
                }
            }
        }

        private void btnhoadon_find_Click(object sender, EventArgs e)
        {
            string searchText = txtBHoaDonCT_find.Text.Trim();

            if (string.IsNullOrEmpty(searchText))
            {
                MessageBox.Show("Vui lòng nhập thông tin cần tìm kiếm.", "Thông báo");
                LoadHDon_ChiTietList();
                return;
            }

            SearchHoaDonChiTiet(searchText);
        }

        private void LoadcomboBoxHD_p_idList()
        {
            SqlConnection con = new SqlConnection(sCon);
            try
            {
                con.Open();

                string query = "SELECT p_id FROM phong_tro";
                SqlCommand command = new SqlCommand(query, con);

                DataTable data = new DataTable();
                SqlDataAdapter adapter = new SqlDataAdapter(command);
                adapter.Fill(data);

                comboBoxHD_p_id.DataSource = data;

                comboBoxHD_p_id.DisplayMember = "p_id";
                comboBoxHD_p_id.ValueMember = "p_id";

            }
            catch (Exception ex)
            {
                MessageBox.Show($"Xảy ra lỗi: {ex.Message}", "Thông báo");
            }
            finally
            {
                con.Close();
            }
        }

        private void ResetFormHoadon()
        {
            txtbHdon_id.Text = string.Empty;
            txtBPprice.Text = string.Empty;
            comboBoxHD_p_id.SelectedIndex = -1;
            numericUpDownHD_tinhtrang.Value = numericUpDownHD_tinhtrang.Minimum;
            txtbHdon_id.Enabled = true;

        }

        private void btnHD_them_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(sCon);
            try
            {
                con.Open();

                string sHD_ID = txtbHdon_id.Text;
                string sHD_p_id = comboBoxHD_p_id.Text;
                string sHD_date = dateTimePickerhd_ngay.Value.ToString("yyyy-MM-dd");
                string sHD_tinhtrang = numericUpDownHD_tinhtrang.Text;

                string query = "INSERT INTO hoa_don (hdon_id, Hdon_NgayThangNam, Hdon_tinhtrang, p_id) " +
                               "VALUES (@hdon_id, @Hdon_NgayThangNam, @Hdon_tinhtrang, @p_id)";

                SqlCommand cmd = new SqlCommand(query, con);
                cmd.Parameters.AddWithValue("@hdon_id", sHD_ID);
                cmd.Parameters.AddWithValue("@Hdon_NgayThangNam", sHD_date);
                cmd.Parameters.AddWithValue("@Hdon_tinhtrang", sHD_tinhtrang);
                cmd.Parameters.AddWithValue("@p_id", sHD_p_id);

                try
                {
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Thêm dữ liệu thành công!", "Thông báo");
                    LoadHDonList();
                    LoadHDonChuaThanhToan();
                    ResetFormHoadon();
                }
                catch (Exception ex)
                {

                    MessageBox.Show("Thêm dữ liệu thất bại! Lỗi: " + ex.Message, "Thông báo");
                    ResetFormHoadon();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Xảy ra lỗi trong quá trình kết nối DB: " + ex.Message, "Thông báo");
            }
            finally
            {
                con.Close();
            }
        }




        private void btnHD_capnhat_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(sCon);
            try
            {
                con.Open();
                string sHD_ID = txtbHdon_id.Text;
                string sHD_p_id = comboBoxHD_p_id.Text;
                string sHD_date = dateTimePickerhd_ngay.Value.ToString("yyyy-MM-dd");
                string sHD_tinhtrang = numericUpDownHD_tinhtrang.Text;

                string query = "UPDATE hoa_don " +
               "SET Hdon_NgayThangNam = @Hdon_NgayThangNam, " +
               "Hdon_tinhtrang = @Hdon_tinhtrang, " +
               "p_id = @p_id " +
               "WHERE hdon_id = @hdon_id"; ;

                SqlCommand cmd = new SqlCommand(query, con);
                cmd.Parameters.AddWithValue("@hdon_id", sHD_ID);
                cmd.Parameters.AddWithValue("@Hdon_NgayThangNam", sHD_date);
                cmd.Parameters.AddWithValue("@Hdon_tinhtrang", sHD_tinhtrang);
                cmd.Parameters.AddWithValue("@p_id", sHD_p_id);

                try
                {
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Cập nhật thành công!", "Thông báo");
                    LoadHDonList();
                    LoadHDonChuaThanhToan();
                    ResetFormHoadon();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Cập nhật thất bại! Lỗi: " + ex.Message, "Thông báo");
                    ResetFormHoadon();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Xảy ra lỗi trong quá trình kết nối DB: " + ex.Message, "Thông báo");
            }
            finally
            {
                con.Close();
            }
        }

        private void dtgvHoaDon_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow selectedRow = dtgvHoaDon.Rows[e.RowIndex];

                txtbHdon_id.Text = selectedRow.Cells["hdon_id"]?.Value?.ToString() ?? "";

                dateTimePickerhd_ngay.Value = selectedRow.Cells["hdon_ngaythangnam"]?.Value != DBNull.Value
                    ? Convert.ToDateTime(selectedRow.Cells["hdon_ngaythangnam"].Value)
                    : DateTime.Now;
                numericUpDownHD_tinhtrang.Text = selectedRow.Cells["hdon_tinhtrang"]?.Value?.ToString() ?? "0";

                if (selectedRow.Cells["hdon_tinhtrang"].Value != DBNull.Value)
                {
                    numericUpDownHD_tinhtrang.Value = Convert.ToInt32(selectedRow.Cells["hdon_tinhtrang"].Value);
                }
                else
                {
                    numericUpDownHD_tinhtrang.Value = 0;
                }
                comboBoxHD_p_id.Text = selectedRow.Cells["p_id"]?.Value?.ToString() ?? "";

                txtbHdon_id.Enabled = false;
            }
        }

        private void btnHdon_Xoa_Click(object sender, EventArgs e)
        {
            DialogResult ret = MessageBox.Show("Bạn có chắc chắn muốn xoá không?", "Thông báo", MessageBoxButtons.OKCancel);
            if (ret == DialogResult.OK)
            {
                SqlConnection con = new SqlConnection(sCon);
                try
                {
                    con.Open();
                    string sHD_ID = txtbHdon_id.Text;


                    string query = "delete from hoa_don where hdon_id= @hdon_id";
                    SqlCommand cmd = new SqlCommand(query, con);
                    cmd.Parameters.AddWithValue("@hdon_id", sHD_ID);

                    try
                    {
                        cmd.ExecuteNonQuery();
                        MessageBox.Show("Xoá thành công!", "Thông báo");
                        LoadHDonList();
                        LoadHDonChuaThanhToan();
                        ResetFormHoadon();
                    }
                    catch
                    {
                        MessageBox.Show("Xoá thất bại!", "Thông báo");
                        ResetFormHoadon();
                    }

                }
                catch (Exception ex)
                {
                    MessageBox.Show("Xảy ra lỗi trong quá trình kết nối DB", "Thông báo");
                }
                finally
                {
                    con.Close();
                }
            }
        }

        private void SearchHoaDon(string searchText)
        {
            using (SqlConnection con = new SqlConnection(sCon))
            {
                try
                {
                    con.Open();

                    string query = @"
                SELECT hdon_id, Hdon_NgayThangNam, Hdon_tinhtrang, p_id
                FROM hoa_don
                WHERE hdon_id LIKE @SearchText
                   OR p_id LIKE @SearchText
                   OR Hdon_NgayThangNam LIKE @SearchText";

                    using (SqlCommand cmd = new SqlCommand(query, con))
                    {
                        cmd.Parameters.Add("@SearchText", SqlDbType.NVarChar).Value = "%" + searchText + "%";

                        SqlDataAdapter da = new SqlDataAdapter(cmd);
                        DataTable dt = new DataTable();
                        da.Fill(dt);

                        if (dt.Rows.Count > 0)
                        {
                            dtgvHoaDon.DataSource = dt;
                        }
                        else
                        {
                            MessageBox.Show("Không tìm thấy kết quả phù hợp.", "Thông báo");
                            dtgvHoaDon.DataSource = null;
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Lỗi khi tìm kiếm dữ liệu: " + ex.Message, "Thông báo");
                }
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            string searchText = txtBHD_finđ.Text.Trim();

            if (string.IsNullOrEmpty(searchText))
            {
                MessageBox.Show("Vui lòng nhập thông tin cần tìm kiếm.", "Thông báo");
                LoadHDonList();
                LoadHDonChuaThanhToan();
                return;
            }

            SearchHoaDon(searchText);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            DialogResult ret = MessageBox.Show("Bạn có chắc chắn muốn xoá không?", "Thông báo", MessageBoxButtons.OKCancel);
            if (ret == DialogResult.OK)
            {
                SqlConnection con = new SqlConnection(sCon);
                try
                {
                    con.Open();
                    string sHD_ID = txtBHD_ID.Text;


                    string query = "delete from hop_dong where hdong_id= @HD_ID";
                    SqlCommand cmd = new SqlCommand(query, con);
                    cmd.Parameters.AddWithValue("@HD_ID", sHD_ID);

                    try
                    {
                        cmd.ExecuteNonQuery();
                        MessageBox.Show("Xoá thành công!", "Thông báo");
                        LoadHop_DongList();
                        ResetFormHopDong();
                    }
                    catch
                    {
                        MessageBox.Show("Xoá thất bại!", "Thông báo");
                        ResetFormHopDong();
                    }

                }
                catch (Exception ex)
                {
                    MessageBox.Show("Xảy ra lỗi trong quá trình kết nối DB", "Thông báo");
                }
                finally
                {
                    con.Close();
                }
            }
        }

        private void btnXoalistviewHDCT_Click(object sender, EventArgs e)
        {
            if (listViewHoaDon.SelectedItems.Count > 0)
            {
                listViewHoaDon.Items.Remove(listViewHoaDon.SelectedItems[0]);
            }
            else
            {
                MessageBox.Show("Vui lòng chọn một mục để xóa.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }
    }
}

