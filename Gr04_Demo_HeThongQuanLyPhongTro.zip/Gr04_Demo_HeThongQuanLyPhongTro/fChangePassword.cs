﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.Data.SqlClient;

namespace hihi
{
    public partial class fChangePassword : Form
    {

        string sCon = "Data Source=LAPTOP-TIPVOAM1;Initial Catalog=PTRO;Integrated Security=True;Trust Server Certificate=True";
        public fChangePassword()
        {
            InitializeComponent();
        }

        private void fChangePassword_Load(object sender, EventArgs e)
        {

        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            string username = txtBUsername.Text.Trim();
            string currentPassword = txtBPassword.Text;
            string newPassword = txtBnewpassw.Text;
            string confirmPassword = txtBnhaplaipw.Text;

            if (string.IsNullOrEmpty(username) || string.IsNullOrEmpty(currentPassword) ||
                string.IsNullOrEmpty(newPassword) || string.IsNullOrEmpty(confirmPassword))
            {
                MessageBox.Show("Vui lòng điền đầy đủ thông tin.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (newPassword != confirmPassword)
            {
                MessageBox.Show("Mật khẩu mới và nhập lại mật khẩu không khớp.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (ChangePassword(username, currentPassword, newPassword))
            {
                MessageBox.Show("Đổi mật khẩu thành công.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                this.Close(); 
            }
            else
            {
                MessageBox.Show("Đổi mật khẩu thất bại. Vui lòng kiểm tra lại.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        private bool ChangePassword(string username, string currentPassword, string newPassword)
        {
            using (SqlConnection con = new SqlConnection(sCon))
            {
                try
                {
                    con.Open();

                    using (SqlCommand cmd = new SqlCommand("USP_ChangePassword", con))
                    {
                        cmd.CommandType = CommandType.StoredProcedure;

                        cmd.Parameters.AddWithValue("@Username", username);
                        cmd.Parameters.AddWithValue("@CurrentPassword", currentPassword);
                        cmd.Parameters.AddWithValue("@NewPassword", newPassword);

                        // Định nghĩa tham số OUTPUT
                        SqlParameter returnValue = new SqlParameter("@ReturnValue", SqlDbType.Int)
                        {
                            Direction = ParameterDirection.Output
                        };
                        cmd.Parameters.Add(returnValue);

                        cmd.ExecuteNonQuery();

                        // Lấy giá trị trả về từ OUTPUT
                        int returnVal = (int)returnValue.Value;

                        if (returnVal == 1)
                        {
                            return true;  // Thành công
                        }
                        else
                        {
                            return false;  // Thất bại
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Lỗi: " + ex.Message, "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return false;
                }
            }
        }



    }
}
