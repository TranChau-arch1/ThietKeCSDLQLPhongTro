﻿namespace hihi
{
    partial class fChangeinf
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            panel3 = new Panel();
            lblAc_CCCD = new Label();
            btnAc_Exit = new Button();
            panel2 = new Panel();
            lblAc_SDT = new Label();
            panel1 = new Panel();
            lblAc_name = new Label();
            pictureBox2 = new PictureBox();
            textBox1 = new TextBox();
            textBox2 = new TextBox();
            textBox3 = new TextBox();
            panel4 = new Panel();
            panel5 = new Panel();
            textBox4 = new TextBox();
            lblAc_add = new Label();
            btnAc_luu = new Button();
            panel3.SuspendLayout();
            panel2.SuspendLayout();
            panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).BeginInit();
            panel4.SuspendLayout();
            panel5.SuspendLayout();
            SuspendLayout();
            // 
            // panel3
            // 
            panel3.Controls.Add(textBox3);
            panel3.Controls.Add(lblAc_CCCD);
            panel3.Location = new Point(33, 133);
            panel3.Name = "panel3";
            panel3.Size = new Size(515, 49);
            panel3.TabIndex = 11;
            // 
            // lblAc_CCCD
            // 
            lblAc_CCCD.AutoSize = true;
            lblAc_CCCD.Location = new Point(11, 15);
            lblAc_CCCD.Name = "lblAc_CCCD";
            lblAc_CCCD.Size = new Size(71, 20);
            lblAc_CCCD.TabIndex = 3;
            lblAc_CCCD.Text = "Số CCCD:";
            // 
            // btnAc_Exit
            // 
            btnAc_Exit.BackColor = Color.Red;
            btnAc_Exit.ForeColor = SystemColors.ButtonFace;
            btnAc_Exit.Location = new Point(520, 392);
            btnAc_Exit.Name = "btnAc_Exit";
            btnAc_Exit.Size = new Size(101, 46);
            btnAc_Exit.TabIndex = 12;
            btnAc_Exit.Text = "Thoát";
            btnAc_Exit.UseVisualStyleBackColor = false;
            // 
            // panel2
            // 
            panel2.Controls.Add(textBox2);
            panel2.Controls.Add(lblAc_SDT);
            panel2.Location = new Point(33, 78);
            panel2.Name = "panel2";
            panel2.Size = new Size(515, 49);
            panel2.TabIndex = 10;
            // 
            // lblAc_SDT
            // 
            lblAc_SDT.AutoSize = true;
            lblAc_SDT.Location = new Point(11, 15);
            lblAc_SDT.Name = "lblAc_SDT";
            lblAc_SDT.Size = new Size(100, 20);
            lblAc_SDT.TabIndex = 3;
            lblAc_SDT.Text = "Số điện thoại:";
            // 
            // panel1
            // 
            panel1.Controls.Add(textBox1);
            panel1.Controls.Add(lblAc_name);
            panel1.Location = new Point(33, 23);
            panel1.Name = "panel1";
            panel1.Size = new Size(515, 49);
            panel1.TabIndex = 9;
            // 
            // lblAc_name
            // 
            lblAc_name.AutoSize = true;
            lblAc_name.Location = new Point(11, 17);
            lblAc_name.Name = "lblAc_name";
            lblAc_name.Size = new Size(76, 20);
            lblAc_name.TabIndex = 3;
            lblAc_name.Text = "Họ và tên:";
            lblAc_name.Click += label1_Click;
            // 
            // pictureBox2
            // 
            pictureBox2.Image = Properties.Resources.account_avatar_face_man_people_profile_user_icon_123197;
            pictureBox2.Location = new Point(287, 7);
            pictureBox2.Name = "pictureBox2";
            pictureBox2.Size = new Size(122, 113);
            pictureBox2.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox2.TabIndex = 8;
            pictureBox2.TabStop = false;
            // 
            // textBox1
            // 
            textBox1.Location = new Point(117, 10);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(344, 27);
            textBox1.TabIndex = 4;
            // 
            // textBox2
            // 
            textBox2.Location = new Point(117, 12);
            textBox2.Name = "textBox2";
            textBox2.Size = new Size(344, 27);
            textBox2.TabIndex = 5;
            // 
            // textBox3
            // 
            textBox3.Location = new Point(117, 8);
            textBox3.Name = "textBox3";
            textBox3.Size = new Size(344, 27);
            textBox3.TabIndex = 6;
            // 
            // panel4
            // 
            panel4.Controls.Add(panel5);
            panel4.Controls.Add(panel1);
            panel4.Controls.Add(panel3);
            panel4.Controls.Add(panel2);
            panel4.Location = new Point(55, 126);
            panel4.Name = "panel4";
            panel4.Size = new Size(566, 253);
            panel4.TabIndex = 13;
            // 
            // panel5
            // 
            panel5.Controls.Add(textBox4);
            panel5.Controls.Add(lblAc_add);
            panel5.Location = new Point(33, 190);
            panel5.Name = "panel5";
            panel5.Size = new Size(515, 49);
            panel5.TabIndex = 12;
            // 
            // textBox4
            // 
            textBox4.Location = new Point(117, 8);
            textBox4.Name = "textBox4";
            textBox4.Size = new Size(344, 27);
            textBox4.TabIndex = 6;
            // 
            // lblAc_add
            // 
            lblAc_add.AutoSize = true;
            lblAc_add.Location = new Point(11, 15);
            lblAc_add.Name = "lblAc_add";
            lblAc_add.Size = new Size(58, 20);
            lblAc_add.TabIndex = 3;
            lblAc_add.Text = "Địa chỉ:";
            // 
            // btnAc_luu
            // 
            btnAc_luu.BackColor = Color.DeepSkyBlue;
            btnAc_luu.ForeColor = SystemColors.ButtonFace;
            btnAc_luu.Location = new Point(398, 392);
            btnAc_luu.Name = "btnAc_luu";
            btnAc_luu.Size = new Size(101, 46);
            btnAc_luu.TabIndex = 14;
            btnAc_luu.Text = "Lưu";
            btnAc_luu.UseVisualStyleBackColor = false;
            // 
            // fChangeinf
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(682, 450);
            Controls.Add(btnAc_luu);
            Controls.Add(panel4);
            Controls.Add(btnAc_Exit);
            Controls.Add(pictureBox2);
            Name = "fChangeinf";
            Text = "fChangeinf";
            panel3.ResumeLayout(false);
            panel3.PerformLayout();
            panel2.ResumeLayout(false);
            panel2.PerformLayout();
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).EndInit();
            panel4.ResumeLayout(false);
            panel5.ResumeLayout(false);
            panel5.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private Panel panel3;
        private TextBox textBox3;
        private Label lblAc_CCCD;
        private Button btnAc_Exit;
        private Panel panel2;
        private TextBox textBox2;
        private Label lblAc_SDT;
        private Panel panel1;
        private TextBox textBox1;
        private Label lblAc_name;
        private PictureBox pictureBox2;
        private Panel panel4;
        private Panel panel5;
        private TextBox textBox4;
        private Label lblAc_add;
        private Button btnAc_luu;
    }
}